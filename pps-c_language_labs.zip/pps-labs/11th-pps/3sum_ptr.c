#include<stdio.h>
int main()
{
  int *p,a[10],i,n,sum=0;
  p=a;//p=&a[0]
  printf("enter the size of array");
      scanf("%d",&n);
      printf("enter array elements");
      for(i=0;i<n;i++)
      scanf("%d",(p+i));
       for(i=0;i<n;i++)
       {
       sum=sum+*p;
       p++;
       }
       printf("sum is %d",sum);
      return 0;
      }
