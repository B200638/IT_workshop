#include<stdio.h>
  int main(){
    int n,j,i,temp,a[10],min;
    printf("enter size of array");
    scanf("%d",&n);
    printf("enter array elements");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    for(i=0;i<n-1;i++){
     for(j=i+1;j<n;j++)
    {
    if(a[i]>a[j]){
    temp=a[i];
    a[i]=a[j];
    a[j]=temp;
    }
    }
    }
    printf("sorted elements are \n");
    for(i=0;i<n;i++)
    {
    printf("%d\n",a[i]);
    }
    return 0;
    }
