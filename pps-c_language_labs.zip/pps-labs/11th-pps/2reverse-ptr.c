#include<stdio.h>
 int main(){
   int *p,i,n;
    int a[10];
    p=a;
    printf("size of array");
    scanf("%d",&n);
    printf("enter array elements");
      for(i=0;i<n;i++)
      scanf("%d",(p+i));
      printf("array enter of reverse order");
      for(i=n-1;i>=0;i--)
      printf("%d\n",*(p+i));
      return 0;
      }
      
