#include<stdio.h>
  int binsch(int[],int,int,int,int);
  int main()
  {
  int a[20],start,end,key,n,mid,ans,i;
  printf("enter the size of the array");
  scanf("%d",&n);
  printf("enter the elements of array\n");
  for(i=0;i<n;i++){
  scanf("%d",&a[i]);
  }
  printf("enter a key");
  scanf("%d",&key);
  start=0;
  end=n-1;
  ans=binsch(a,n,start,end,key);
  printf("%d",ans);
  }
  int binsch(int a[],int n,int start,int end,int key)
  {
  if(start<=end)
  {
  int mid=(start+end)/2;
  if(key==a[mid]){
  return mid;
  }
  else if(key<a[mid])
  {
  return binsch(a,n,mid+1,end,key);
  }
  }
  else
  {
  return 0;
  }
  }
