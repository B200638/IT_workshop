#include<stdio.h>
  int main()
  {
    int i,arr[10];
    int*parr=arr;
    printf("enter elements");
    for(i=0;i<10;++i)
    scanf("%d",arr+i);
    printf("enter the value\n");
    for(int i=0;i<10;++i)
    printf("%d\n",*(arr+i));
    return 0;
    }
