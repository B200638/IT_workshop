#include<stdio.h>
#include<math.h>
int main(){
   float p,t,r,n,si,ci;
   printf("enter principal amount(p):");
   scanf("%f",&p);
   printf("enter time in year(t):");
   scanf("%f",&t);
   printf("enter rate in percent(r):");
   scanf("%f",&r);
   printf("enter number of time instrest applied per time(n):");
   scanf("%f",&n);
   si=(p*t*r)/100;
   ci=p*(pow((1+r/n),(n*t)));
   printf("simple intrest=%f",si);
   printf("compound intrest=%f",ci);
   return 0;
   }
