#include<stdio.h>
#include<math.h>
int main()
{
  float p,t,r;
  printf("enter principle amount :");
  scanf("%f", &p);
  printf("enter time period :");
  scanf("%f", &t);
  printf("enter rate of intrest :");
  scanf("%f", &r);
  int simple_intrest=p*t*r/100;
  printf("simple intrest is: %d\n",simple_intrest);
  int compound_intrest=p*pow(1+(r/100),t);
  printf("compound intrest is :%d\n",compound_intrest);
  return 0;
}

