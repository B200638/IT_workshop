#include<stdio.h>
int main() {
  int num,i,sum=0;
  printf("enter any positive number:");
  scanf("%d",&num);
  for(i=0;i<=num;i++)
  {
    sum=sum+i;
    }
    printf("\n sum of the first %d number is:%d",num,sum);
    return 0;
    }
