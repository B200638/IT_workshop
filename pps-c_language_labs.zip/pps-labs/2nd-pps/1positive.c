#include<stdio.h>
int main() {
int a;
  printf("enter a value:");
  scanf("%d",&a);
    if(a==0)
  printf("\nentered number is zero");
    if(a%2==0&&a>0)
  printf("\nentered number is even and positive");
    if(a%2!=0&&a<0)
  printf("\nentered number is odd and negitive");
    if(a%2!=0&&a>0)
  printf("\nentered number is odd and positive");
    return 0;  
  }


