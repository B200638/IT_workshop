#include<stdio.h>
 void main()
  {
   int n,i;
  /*printf("enter the number");
   scanf("%d",&n);*/
   for(i=0;i<=50;i++){
   n=i;
   while(n>0){
   if(n>=50){
   n=n-50;
   printf("L");}
   else if(n>=40){
   n=n-40;
  printf("XL");}
  else if(n>=10){
  n=n-10;
  printf("X");}
  else if(n>=9){
  n=n-9;
  printf("IX");}
  else if(n>=5){
  n=n-5;
  printf("V");}
  else if(n>=4){
  n=n-4;
  printf("IV");}
  else if(n>=1){
  n=n-1;
  printf("I");}
  }
  printf("\n");
  }
  } 
  

   
   
