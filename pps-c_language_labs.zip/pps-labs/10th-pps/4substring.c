#include<stdio.h>
#include<string.h>
  int main()
  {
  char a[10];
  char b[10];
  char c[10];
  int p=0,i=0,r=0;
  int t=0;
  int x,g,y,n,o;
  printf("enter first sring");
  scanf("%s",a);
  printf("enter second string");
 scanf("%s",b);
  printf("enter the position of string");
  scanf("%d",&p);
  r=strlen(a);
  
 n=strlen(b);
  i=0;
  while(i<=r)
  {
    c[i]=a[i];
    i++;
    }
    y=n+r;
    o=p+n;
    for(i=p;i<y;i++)
    {
      x=c[i];
      if(t<n)
      {
       a[i]=b[t];
       t=t+1;
       }
       a[o]=x;
       o=o+1;
       }
       printf("%s",a);
       return 0;
       }
