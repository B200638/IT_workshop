#include<stdio.h>
#include<math.h>
  int main()
  {
  int i,j,n,mean,sum=0,ams=0,msd,sd,a[n],dms[n];
  printf("enter number of terms\n");
  scanf("%d",&n);
  printf("enter numbers\n");
  for(i=0;i<n;i++)
  {
  scanf("%d",&a[i]);
  sum+=a[i];
  }
  mean=(int)(sum/n);
  printf("mean for given number is %d\n",mean);
  for(i=0;i<n;i++)
  {
  dms[i]=(a[i]-mean)*(a[i]-mean);
  ams+=dms[i];
  }
  msd=(int)(ams/n);
  sd=(int)(sqrt(msd));
  printf("variance=%d\n",msd);
  printf("standard deviation=%d\n",sd);
  return 0;
  }
  

