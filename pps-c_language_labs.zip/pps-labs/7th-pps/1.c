#include<stdio.h>
  int main()
  {
   int a[4],i,n,sum=0,max,min,avg;
   printf("enter the size of the array");
   scanf("%d",&n);
   printf("enter n element to array");
   for(i=0;i<n;i++)
   {
   scanf("%d",&a[i]);
   sum=sum+a[i];
   }
   max=a[0];
   for(i=0;i<n;i++)
   {
   if(a[i]>max)
   {
   max=a[i];
   }
     }
     min=a[0];
   for(i=0;i<n;i++)
   {
   if(a[i]<min)
   {
   min=a[i];
   }  
     }
   avg=sum/n;
   printf("averag %d\n",avg);
   printf("the max of array %d\n",max);
   printf("the min of array %d\n",min);
   }
   
   
