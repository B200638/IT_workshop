#include<stdio.h>
float main()
{
  float l,b,perimeter,area;
  printf("enter the number");
  scanf("%f%f",&l,&b);
  area=l*b;
  printf("%f is area of the rectangle\n",area);
  perimeter=2*(l+b);
  printf("%f is perimeter of the rectangle\n",perimeter);
  return 0;
}
  
