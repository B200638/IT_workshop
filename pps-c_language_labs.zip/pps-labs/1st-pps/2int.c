#include<stdio.h>
int main ()
{
 int a,b,add,sub,mul,div;
 printf("enter a value");
 scanf("%d%d",&a,&b);
 add=a+b;
 printf("%d\n",add);
 sub=a-b;
 printf("%d\n",sub);
 mul=a*b;
 printf("%d\n",mul);
 div=a%b;
 printf("%d\n",div);
 return 0;
}
