#include<stdio.h>
float main()
{
  float r,area,perimeter;
  printf("enter r value");
  scanf("%f",&r);
  area=3.14*r*r;
  printf("%f is area of the circle\n",area);
  perimeter=2*3.14*r;
  printf("%f is perimeter of the circle\n",perimeter);
  return 0;
}
