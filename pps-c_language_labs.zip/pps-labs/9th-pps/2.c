#include<stdio.h>
  int main()
  {
    int n,i, fact;
    printf("enter the value");
    scanf("%d",&n);
    fact=factorial(n);
    printf("%d",fact);
    }
    int factorial(int x)
    {   
      if(x==1||x==0)
      return(1);
      else
      return(x*factorial(x-1));
      }
