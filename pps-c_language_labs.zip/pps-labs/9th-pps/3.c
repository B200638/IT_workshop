#include<stdio.h>
  int power(int,int);
 int main()
 {
   int a,b,c;
   printf("enter two values");
   scanf("%d%d",&a,&b);
   c=power(a,b);
   printf("%d",c);
    }
   int power(int x,int y)
   {
     if(y==0){
     return 1;
     }
     else
     return x*power(x,y-1);//(base*power(base,a-1));
     }
 
