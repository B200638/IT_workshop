#include<stdio.h>
int gcd(int,int);
  int main()
  {
    int a,b,c;
    printf("enter the two value");
    scanf("%d%d",&a,&b);
    c = gcd(a,b);
    printf("%d",c);}
  int gcd(int x , int y)
  {
  if(x==0) 
   return y ;
  else if(y==0) 
   return x ;
  else if (x>y)
   return gcd(x-y,y);
  else 
   return gcd(x,y-x);}
