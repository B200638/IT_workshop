#include<stdio.h>
int main(){
 int n;
 int count=0;
 printf("enter the value:");
 scanf("%d",&n);
 do{
 n/=10;
 count++;
 }while (n!=0);
 printf("number of digits:%d",count);
 }
