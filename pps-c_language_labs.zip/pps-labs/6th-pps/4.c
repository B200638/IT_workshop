#include<stdio.h>
#include<math.h>
  int main(){
  int i,x,n,sum=0;
  printf("enter the value of n,x:");
  scanf("%d%d",&n,&x);
  for(i=0;i<=n;i++)
  sum=sum+pow(x,i);
  printf("%d",sum);
  return 0;
  }
