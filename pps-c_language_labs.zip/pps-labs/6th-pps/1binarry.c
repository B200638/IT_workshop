#include<stdio.h>
int main()
{
int i,n,binary,j,r;
int arr[8],rev=0;
printf("enter the value");
scanf("%d",&n);
for(i=0;n!=0;i++)
{
r=n%2;
arr[i]=r;
n=n/2;
}
for(j=i-1;j>=0;j--)
{
printf("%d",arr[j]);
}
return 0;
}
