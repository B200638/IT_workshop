#include<stdio.h>
int main()
{
int f1=0,f2=1,f3,i,n;
 printf("enter the value of number");
  scanf("%d",&n);
  for(i=0;i<=n;i++)
 {
   printf("\n%d",f1);
   f3=f1+f2;
   f1=f2;
   f2=f3;
   }
   f3=f1+f2;
   f2=f2;
   f2=f3;
   printf("\n%d",f2);
   return 0;
 }
