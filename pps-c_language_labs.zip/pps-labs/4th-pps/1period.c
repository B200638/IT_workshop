#include<stdio.h>
#include<math.h>
 float main() {
  float f=10,s=30,a=9.8;
  float t;
  while(f>0)
  {
  t=sqrt(2*s/a);
  printf("\n%f",t);
  f=f-1;
  s=s-3;
  }
  return 0;
  }
