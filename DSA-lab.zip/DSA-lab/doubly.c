#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
struct node *prev;
};
struct node *start=NULL;
struct node *create(struct node *start);
struct node *display(struct node *start);
struct node *insert_beg(struct node *start);
struct node *insert_end(struct node *start);
struct node *insert_pos(struct node *start);
struct node *delete_beg(struct node *start);
struct node *delete_end(struct node *start);
struct node *delete_pos(struct node *start);
int main()
{
int choice;
do
{
printf("\n\nOperations on a doubly Linked List\n");
printf("1.Create a Linked List\n");
printf("2.Display Linked List\n");
printf("3.Add a node at the beginning \n");
printf("4.Add a node at the end\n");
printf("5.Add a node after a given node\n");
printf("6.Delete a node from the beginning \n");
printf("7.Delete a node from the end\n");
printf("8.Delete a given node\n");
printf("9.Exit\n");
printf("Enter your Choice\n");
scanf("%d",&choice);
switch(choice)
{
case 1:start=create(start);
printf("doubly Linked List is Created\n");
break;
case 2:start=display(start);
break;
case 3:start=insert_beg(start);
break;
case 4:start=insert_end(start);
break;
case 5:start=insert_pos(start);
break;
case 6:start=delete_beg(start);
break;
case 7:start=delete_end(start);
break;
case 8:start=delete_pos(start);
break;
default:
printf("exited");
}
}
while(choice==1||choice==2||choice==3||choice==4||choice==5||choice==6||choice==7||choice==8);
return 0;
}

//creating a list
struct node *create(struct node *start)
{
struct node *new_node,*current;
int num;
printf("Enter -1 to stop creating more nodes\n");
printf("Enter the data\n");
scanf("%d",&num);
while(num!=-1)
{
new_node=(struct node *)malloc(sizeof(struct node));
new_node->data=num;
if(start==NULL)
{
current=start=new_node;
}
else
{
current->next=new_node;
new_node->prev=current;
current=new_node;
}
printf("Enter the data\n");
scanf("%d",&num);
}
return start;
}

//displaying the list:
struct node *display(struct node *start)
{
struct node *current;
current=start;
while(current->next!=NULL)
{
printf("%d",current->data);
current=current->next;
}
printf("%d",current->data);
return start;
}

//inserting node at beginning:
struct node *insert_beg(struct node *start)
{
struct node *new_node;
int num;
printf("Enter the data which has to be inserted at the beginning\n");
scanf("%d",&num);
new_node=(struct node*)malloc(sizeof(struct node));
new_node->data=num;
new_node->prev=NULL;
new_node->next=NULL;
new_node->next=start;
start->prev=new_node;
start=new_node;
return start;
}

//inserting node at end:
struct node *insert_end(struct node *start)
{
struct node *new_node,*current;
new_node=(struct node*)malloc(sizeof(struct node));
printf("enter the data to be inserted at end\n");
scanf("%d",&new_node->data);
current=start;
while(current->next!=NULL)
{
current=current->next;
}
new_node->next=NULL;
new_node->prev=current;
current->next=new_node;
return start;
}

//inserting a node certain position:
struct node *insert_pos(struct node *start)
{
struct node *new_node,*current;
int num,val;
new_node=(struct node*)malloc(sizeof(struct node));
printf("Enter the position at which node has to inserted\n");
scanf("%d",&val);
printf("Enter the data\n");
scanf("%d",&num);
new_node->data=num;
current=start;
while(current->data!=val)
{
current=current->next;
}
current->next->prev=new_node;
new_node->next=current->next;
new_node->prev=current;
current->next=new_node;
return start;
}

//delete node at beginning:
struct node *delete_beg(struct node *start)
{
struct node *current;
current=start;
start=current->next;
current->next->prev=NULL;
current->next=NULL;
free(current);
return start;
 }

 //delete node at end:
struct node *delete_end(struct node *start)
{
struct node *current,*prev;
current=start;
while(current->next!=NULL)
{
prev=current;
current=current->next;
}
prev->next=NULL;
current->prev=NULL;
free(current);
return start;
}

//delete node at certain position:
struct node *delete_pos(struct node *start)
{
struct node *current,*prev;
int val;
printf("Enter the value of the node which has to be deleted\n");
scanf("%d",&val);
current=start;
while(current->data!=val)
{
prev=current;
current=current->next;
}
prev->next=current->next;
current->next->prev=prev;
free(current);
return start;
}



