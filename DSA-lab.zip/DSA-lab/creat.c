#include<stdio.h>
#include<stdlib.h>
  struct node {
  int data;
  struct node *link;
  };
  struct node *start=NULL,*new_node;
   int value;
  printf("enter the value: ");
  scanf("%d",&value);
  new_node=(struct node*)malloc(sizeof(struct node));
  new_node->data=value;
  new_node->link=NULL;
  printf("%d",new_node->data);
  
