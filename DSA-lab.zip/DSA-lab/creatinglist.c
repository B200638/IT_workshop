#include<stdio.h>
#include<stdlib.h>
 struct node
 {
  int data;
  struct node *next;
  };
  struct node *start=NULL;
  struct node *create(struct node*);
  struct node *display(struct node*);
  int main()
  {
  int choice;
  do
  {
  printf("1.create alinked list\n");
  printf("2.display the linked list\n");
  printf("enter your choice ");
  scanf("%d",&choice);
  switch(choice)
  {
  case 1:start=create(start);
  printf("singly linked list is created\n");
  break;
  case 2:start=display(start);
  break;
  }
  }
  while(choice==1||choice==2);
  return 0;
  }
  struct node *create(struct node *start)
  {
  struct node *new_node,*current;
  int num;
  printf("enter -1 ti stop creating more nodes \n");
  printf("enter the data\n");
  scanf("%d",&num);
  while(num!=1)
  {
  new_node=(struct node*)malloc(sizeof(struct node));
  new_node->data=num;
  if(start==NULL)
  {
  new_node->next=NULL;
  start=new_node;
  }
  else
  {
  current=start;
  while(current->next!=NULL)
  current=current->next;
  current->next=new_node;
  new_node->next=NULL;
  }
  printf("enter the data\n");
  scanf("%d",&num);
  }
  return start;
  }
  struct node *display(struct node *start)
  {
  struct node *current;
  current=start;
  printf("the linked list is\n");
  printf("\n");
  return start;
  while(current!=NULL)
  {
  printf("%d",current->data);
  current=current->next;
  }
  }
 
 
