#include<stdio.h>
#include<stdlib.h>
struct node{
 int data;
 struct node *next;
 };
 struct node *start=NULL;
 void main()
 {
 struct node *current,*newnode;
 int num;
 printf("enter the data");
 scanf("%d",&num);
 while(num!=-1)
 {
  newnode=(struct node *)malloc(sizeof(struct node));
  newnode->data=num;
  if(start==NULL)
  {
  start=newnode;
  newnode->next=NULL;
  }
  else
  {
    current=start;
   while(current->next!=NULL)
   current=current->next;
   current->next=newnode;
   newnode->next=NULL;
   }
   printf("enter the data");
   scanf("%d",&num);
   }
   current=start;
   printf("the linked list has\n");
   while(current->next!=NULL)
   {
   printf("%d",current->data);
   current=current->next;
   }
   }
