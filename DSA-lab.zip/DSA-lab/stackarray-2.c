#include<stdio.h>
#include<stdlib.h>
#define n 5
void push();
void pop();
void display();
int stack[n],top=-1;
int main()
{
int choice;
printf("1.to push the elements into the stack\n");
printf("2.to pop the elements of the stack\n");
printf("3.to display the stack\n");
printf("4.exit\n");
while(1)
{
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:push();
break;
case 2:pop();
break;
case 3:display();
break;
case 4:exit(0);
break;
default:
printf("invalid\n");
}
}
}


//inserting an element into the stack:
void push()
{
int x;
if(top==n-1)
{
printf("stack is full\n");
}
else
{
printf("enter the element\n");
scanf("%d",&x);
top++;
stack[top]=x;
}
}

//delete the last element from the stack:
void pop()
{
if(top==-1)
{
printf("stack is empty\n");
}
else
{
printf("elment removed from stack is%d\n",stack[top]);
top--;
}
}

//displaying the stack:
void display()
{
int i;
if(top==-1)
{
printf("empty stack\n");
}
else
{
for(i=top;i>=0;i--)
{
printf("%d",stack[i]);
}
}
}







