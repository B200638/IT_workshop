#include<stdio.h>
#include<stdlib.h>
void enqueue();
void dequeue();
void display();
int queue[20],n,front=-1,rear=-1;
int main()
{
printf("enter the size of the queue");
scanf("%d",&n);
int choice;
do
{
printf("1.to insert elements into the queue\n");
printf("2.to delete the elements from the queue\n");
printf("3.to display the elements in the queue\n");
printf("4.exit\n");
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:enqueue();
break;
case 2: dequeue();
break;
case 3:display();
break;
default:
printf("exited\n");
}
}
while(choice==1||choice==2||choice==3);
}
void enqueue()
{
int x;
printf("enter the element");
scanf("%d",&x);
if(rear==n-1)
{
printf("queue is full\n");
}
else if(front!=-1&&rear==-1)
{
front=0;
rear=0;
queue[rear]=x;
}
else
{
rear++;
queue[rear]=x;
}
}

void dequeue()
{
if(front==-1&&rear==-1)
{
printf("queue is empty\n");
}
else if(front==rear)
{
front=-1;
rear=-1;
}
else
{
printf("deleted element is %d\n",queue[front]);
front++;
}
}

void display()
{
int i;
if(front==-1&&rear==-1)
{
printf("queue is empty");
}
else
{
for(i=front;i<=rear;i++)
{
printf("%d\t",queue[i]);
}
}
}



