#include<stdio.h>
#define MAX 10
int a[MAX];
int get_left_child(int);
int get_right_child(int);
int inorder(int);
int preorder(int);
int postorder(int);
void insert_node(int);
int i=0;
int main()
{
int data,n,i=0;
printf("enter the size");
scanf("%d",&n);
for(i=0;i<n;i++)
{
printf("enetr the data");
scanf("%d",&data);
insert_node(data);
}
printf("inorder traversal is\n");
inorder(0);
printf(" \n");
printf("preorder traversal is\n");
preorder(0);
printf(" \n");
printf("postorder traversal is\n");
postorder(0);
printf(" \n");
}
void insert_node(int data)
{
if(i>MAX-1)
{
printf("full\n");
return;
}
a[i]=data;
i++;
}
int inorder(int index)
{
if(index<i)
{
inorder(get_left_child(index));
printf("%d",a[index]);
inorder(get_right_child(index));
}
}
int preorder(int index)
{
if(index<i)
{
printf("%d",a[index]);
preorder(get_left_child(index));
preorder(get_right_child(index));
}
}
int postorder(int index)
{
if(index<i)
{
postorder(get_left_child(index));
postorder(get_right_child(index));
printf("%d",a[index]);
}
}
int get_left_child(int i)
{
return((2*i)+1);
}
int get_right_child(int i)
{
return((2*i)+2);
}


