#include<stdio.h>
#include<stdlib.h>
#define n 5
void enqueue();
void dequeue();
void display();
int queue[n],front=-1,rear=-1;
int main()
{
int choice;
printf("1.to insert elements into the queue\n");
printf("2.to delete the elements from the queue\n");
printf("3.to display the elements in the queue\n");
printf("4.exit\n");
while(1)
{
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:enqueue();
break;
case 2: dequeue();
break;
case 3:display();
break;
case 4:exit(0);
break;
default:
printf("invalid\n");
}
}}
void enqueue()
{
int x;
printf("enter the element");
scanf("%d",&x);
if(rear==n-1)
{
printf("queue is full\n");
}
if(front==-1&&rear==-1)
{
front=rear=0;
queue[rear]=x;
}
else
{
rear++;
queue[rear]=x;
}
}

void dequeue()
{
if(front==-1&&rear==-1)
{
printf("queue is empty\n");
}
else if(front==rear)
{
front=-1;
rear=-1;
}
else
{
printf("deleted element is %d\n",queue[front]);
front++;
}
}

void display()
{
int i;
if(front==-1&&rear==-1)
{
printf("queue is empty");
}
else
{
for(i=front;i<=rear;i++)
{
printf("%d\t",queue[i]);
}
}
}



