#include<stdio.h>
 void enque();
 void deque();
 void display();
 int queue[100],front=-1,rear=-1;
 int x,choice,rear,front,n;
 int main()
{
do
{
  printf("1.insert the queue \n");
  printf("2.delete the queue \n");
  printf("3.display the queue\n");
  printf("4. exit the queue \n");
  printf("enter your choice\n");
  scanf("%d",&choice);
  switch(choice)
		{
			case 1:	enque();
				printf("insert the element\n");
				break;
			case 2:	deque();
			        printf("delete the elment\n");
				break;
			case 3:	display();
				printf("delete the element\n");
				break;
				}
  }
	while(choice==1||choice==2||choice==3);
	return 0;
	}
  void enque()
   {
  int x;
  printf("enter the element");
  if(rear==n-1)
  {
  printf("queue is full");
  {
  front=0;
  rear=0;
  queue[rear]=x;
  }
  }
 else
  {
  rear++;
  queue[rear]=x;
  }
  }
  void deque()
  {
  if(front==1&&rear==-1)
  {
  printf("empty");
  }
  else if (front==rear)
  {
  front=-1;
  rear=-1;
  }
  else
  {
  printf("delete element %d",queue[front]);
  front++;
  }
  }
  void display()
  {
   int i;
   if(front==-1)
   {
   front==-1;
   }
   else
   {
   for(i=front;i>=0;i--)
   {
   printf("%d",queue[i]);
   }
   }
   }
 
	
