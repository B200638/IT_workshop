#include<stdio.h>
#include<stdlib.h>
#define MAX_VERTICES 5
int adj[MAX_VERTICES][MAX_VERTICES];
//function to add edge to the graph
void addedge(int x,int y)
{
adj[x][y]=1;
adj[y][x]=1;
}
//function to perform bfs on the graph
void bfs(int start)
{
int visited[MAX_VERTICES]={0};
int q[MAX_VERTICES];
int front=0,rear=0;
q[rear++]=start;
//set source as visited
visited[start]=1;
int vis;
while(front<rear)
{
vis=q[front++];
//print the current node
printf("%d",vis);
//for every adjenct vertex to the
for(int i=0;i<MAX_VERTICES;i++)
{
if(adj[vis][i]==1&&!visited[i]){
//push the adj node to the queue
q[rear++]=i;
//set visited
visited[i]=1;
}
}
}
}
int main(){
 int v=5;
 //adjecent matrix
 for(int i=0;i<MAX_VERTICES;i++)
 {
 for(int j=0;j<MAX_VERTICES;j++)
 {
 adj[i][j]=0;
 }
 }
 addedge(0,0);
 addedge(0,2);
 addedge(1,3);
 //perform bfs on graph
 bfs(0);
 return 0;
  }
  
