#include<stdio.h>
#include<stdlib.h>
void reverse();
struct node
{
int data;
struct node *next;
};
struct node *start=NULL;
void main()
{
struct node *current,*new_node;
int choice,num;
printf("enter the data");
scanf("%d",&num);
while(num!=-1)
{
new_node=(struct node*)malloc(sizeof(struct node));
new_node->data=num;
new_node->next=NULL;
if(start==NULL)
{
start=current=new_node;
}
else
{
current->next=new_node;
current=new_node;
}
printf("enter the data");
scanf("%d",&num);
}
current=start;
while(current!=NULL)
{
printf("%d",current->data);
current=current->next;
}
reverse();
}
void reverse()
{
struct node *current,*next_node;
struct node *prev=NULL;
current=next_node=start;
while(next_node!=NULL)
{
next_node=next_node->next;
current->next=prev;
prev=current;
current=next_node;
}
start=prev;
printf("\n after reversing the list\n");
current=start;
while(current!=NULL)
{
printf("%d",current->data);
current=current->next;
}
}
