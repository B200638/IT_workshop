#include<stdio.h>
#include<stdlib.h>
#define max 5
int queue[max];
int front=-1,rear=-1;
void enque();
void deque();
void display();
int main()
{
int choice;
printf("1.insert an element in queue\n2.delete an element in queue\n3.display\n4.exit\n");
while(1)
{
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:
enque();
break;
case 2:
deque();
break;
case 3:
display();
break;
case 4:
exit(0);
break;
default:
printf("wrong choice");}}}
void enque()
{
int data;
printf("enter data to enque");
scanf("%d",&data);
if(rear==max-1||front==rear+1%max)
printf("queue is full");
else if(front==-1&&rear==-1)
{
front=0;
rear=0;
queue[rear]=data;}
else
{
rear=rear+1%max;
queue[rear]=data;
}}
void deque()
{
if(front==-1&&rear==-1)
printf("empty queue\n");
else if(front==rear)
{
front=-1;rear=-1;}
else
{
printf("%d",queue[front]);
front=front+1%max;
}}
void display()
{

int i;
if(front==-1&&rear==-1)
printf("queue i empty");
for(i=front;i!=rear;i=(i+1)%max)
{
printf("%d",queue[i]);}
printf("%d",queue[i]);}

