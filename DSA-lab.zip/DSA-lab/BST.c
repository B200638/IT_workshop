#include<stdio.h>
#include<stdlib.h>
struct treenode{
int data;
struct tree *left;
struct tree *right;
};
struct treenode *createnode(int data)
{
struct treenode *newnode=(struct treenode*)malloc(sizeof(struct treenode));
newnode->data=data;
newnode->left=newnode->right=NULL;
return newnode;
}
struct treenode*insert(struct treenode *root,int data)
{
if(root==NULL)
{
return createnode(data);
{
root->left=insert(root->left,data);
}
else if(data>root->data)
{
root->right=insert(root->right,data);
}
return root;
}
struct treenode *search(struct treenode *root,int key)
{
if(root==NULL||root->data==key){
return root;
}
if(key<root->data)
{
return search(root->left,key);
}
return search(root->right,key);
}
struct treenode *findmin(struct treenode *root)
{
while(root->left!=NULL)
{
root=root->left;
struct treenode *deletenode(struct treenode *root,int key)
{
if(root==NULL)
{
return root;
}
if(key<root->data)
{
root->left=deletenode(root->left,key);
}
else if(key>root->data)
{
root->right=deletenode(root->right,key);
}
else
{
if(root->left==NULL)
{
struct treenode *temp=root->right;
free(root);
return temp;
}
else if(root->right==NULL)
{
struct treenode *temp=root->next;
free(root);
return temp;
}
struct treenode *temp=findmin(root->right);
root->data=temp->data;
root->right=deletenode(root->right,temp->data);
}
return root;
}
int main()
{
struct treenode *root=NULL;
int choice,key;
do{
printf("\n binary search tree opereation\n");
printf("1.insert\n,2.search\n,3.delete\n,4.exit\n");
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:printf("enter value to insert ");
scanf("%d",&key);
root=insert(root,key);
break;
case 2:printf("enter value to search");
scanf("%d",&key);
if(search(root,key))
{
printf("%d found in the bst\n",key);
}
else
{
printf("%d not found in the bst\n",key);
}
break;
case 3:printf("enter value to deiete");
scanf("%d",&key);
root=deletenode(root,key);
break;
{
case 4:printf("existing the program\n");
break;
default:
printf("invalid choice");
} }
while(choice!=4);
return 0;
}


