#include<stdio.h>
#include<stdlib.h>
int queue[20];
void enqueue();
void dequeue();
void display();
struct node
{
int data;
struct node *next;
};
struct node *front,*rear,*temp;
int main()
{
int choice;
printf("1.to insert element into the queue\n");
printf("2.to delete the element in the queue\n");
printf("3.to display the element in the queue\n");
printf("4.exit\n");
while(1)
{
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:enqueue();
printf("queue is create\n");
break;
case 2:dequeue();
break;
case 3:display();
break;
case 4:exit(0);
break;
default:
printf("invalid\n");
}
}
}
void enqueue()
{
struct node *new_node;
int num;

new_node=(struct node*)malloc(sizeof(struct node));
printf("enter the element");
scanf("%d",&num);
new_node->data=num;
new_node->next=NULL;
if(front==NULL&&rear==NULL)
{
front=new_node;
rear=new_node;
}
else
{
rear->next=new_node;
rear=new_node;
}
}

void dequeue()
{
if(front==NULL&&rear==NULL)
{
printf("queue is empty\n");
}
else if(rear==front)
{
printf("the popped elment is%d",front->data);
rear=front=NULL;
}
else
{
printf("%d",front->data);
front=front->next;
}
}

void display()
{
temp=front;
if(temp==NULL)
{
printf("queue is empty\n");
}
else
{
printf("the queue contains");
while(temp->next!=NULL)
{
printf("%d",temp->data);
temp=temp->next;
}
printf("%d",temp->data);
printf("\n");
}
}
