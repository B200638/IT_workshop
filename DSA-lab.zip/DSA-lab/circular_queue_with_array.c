//circular queue with array
#include<stdio.h>
#include<stdlib.h>
#define size 5
int items[size];
int front=-1,rear=-1;
int isfull(){
if((front==rear+1)||(front==0&&rear==size-1))
return 1;
return 0;
}
int isempty(){
if(front==-1)
return 1;
return 0;
}
void enqueue(){
if(isfull())
printf("\n queue is full\n");
else
{
int element;
printf("enter element to insert");
scanf("%d",&element);
if(front==-1)front=0;
rear=(rear+1)%size;
items[rear]=element;
printf("\n insert ->%d",element);
}}
int dequeue(){
int element;
if(isempty()){
printf("\nqueue is empty !!\n");
return(-1);
}
else{
element=items[front];
if(front==rear){
front=-1;
rear=-1;
}
else{
front=(front+1)%size;
}
printf("\n deleted element ->%d\n",element);
return(element);
}
}
void display(){
int i;
if(isempty())
printf("\nempty queue\n");
else{
printf("\n items");
for(i=front;i!=rear;i=(i+1)%size){
printf("%d",items[i]);
}
printf("%d",items[i]);
}
}
int main(){
int choice;
printf("1.enqueue\n2.dequeue\n3.display\n4.exit\n");
while(1)
{
printf("enter your choice \n");
scanf("%d",&choice);
switch(choice)
{
case 1:
enqueue();break;
case 2:
dequeue();break;
case 3:
display();break;
case 4:
exit(0);break;
default:
printf("invalid choice");}}}


