#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *left;
struct node *right;
};
struct node *create()
{
struct node *new_node;
int n;
new_node=(struct node *)malloc(sizeof(struct node));
printf("enter the data or -1 if no data");
scanf("%d",&n);
if(n==-1)
return NULL;
new_node->data=n;
printf("enter the left child of %d",n);
new_node->left=create();
printf("enter the right child of %d",n);
new_node->right=create();
return new_node;
}
void preorder(struct node *root)
{
if(root!=NULL)
{
printf("%d",root->data);
preorder(root->left);
preorder(root->right);
}
}
void inorder(struct node *root)
{
if(root!=NULL)
{
inorder(root->left);
printf("%d",root->data);
inorder(root->right);
}
}
void postorder(struct node *root)
{
if(root!=NULL)
{
postorder(root->left);
postorder(root->right);
printf("%d",root->data);
}
}
int main()
{
struct node *root=NULL;
root=create();
if(root==NULL)
return 0;
printf("preorder travelsal is");
preorder(root);
printf("\n");
printf("inorder travelsal is");
inorder(root);
printf("\n");
printf("postorder travelsal is");
postorder(root);
printf("\n");
}






