#include<stdio.h>
#include<stdlib.h>
void push();
void pop();
void display();
struct node
{
int data;
struct node *next;
};
struct node *top=NULL;
int main()
{
int choice;
printf("1.to push element into the stack\n");
printf("2.to pop the elment in the stack\n");
printf("3.to display the stack elements\n");
printf("4.exit\n");
while(1)
{
printf("enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:push();
break;
case 2:pop();
break;
case 3:display();
break;
case 4:exit(0);
break;
default:
printf("invalid\n");
}
}
}
void push()
{
struct node *new_node;
int num;
//printf(" creating the stack \n");
printf("enter the data");
scanf("%d",&num);
new_node=(struct node*)malloc(sizeof(struct node));
new_node->data=num;
new_node->next=NULL;
if(top==NULL)
{
top=new_node;
}
else
{
new_node->next=top;
top=new_node;
}
}

void pop()
{
struct node *temp;
if(top==NULL)
{
printf("stack is empty\n");
}
else
{
temp=top;
printf("%d",top->data);
top=top->next;
free(temp);
}
}
void display()
{
struct node *current;
current=top;
if(top==NULL)
{
printf("stack is empty \n");
}
else
printf("your stack contains\n");
{
while(current->next!=NULL)
{
printf("%d",current->data);
current=current->next;
}
printf("%d\n",current->data);
}
}

