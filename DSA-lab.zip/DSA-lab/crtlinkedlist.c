#include<stdio.h>
#include<stdlib.h>
 struct node
 {
  int data;
  struct node *next;
  };
  void printlist(struct node*n)
  {
  while(n!=NULL)
  {
  printf("%d",n->data);
  n=n->next;
  }
  }
  int main()
  {
  int n,i;
  struct node *head=NULL;
  struct node *prev=NULL;
  struct node *current=NULL;
  printf("enter the number of nodes");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
  current=(struct node*)malloc(sizeof(struct node));
  printf("enter the data for node %d",i+1);
  scanf("%d",&current->data);
  if(head==NULL){
  head=current;
  }
  else
  {
  prev->next=current;
  }
  current->next=NULL;
  prev=current;
  }
  printlist(head);
  return 0;
  }
 
