#include<stdio.h>
#include<math.h>
int stack[20];
int top=-1;
void push(int);
void pop();
int sum();
int diff();
int mul();
int div();
int power();
int main()
{
char exp[20];
printf("enter the postfix expression\n");
scanf("%s",exp);
int i;
for(i=0;exp[i]!='\0';i++)
{
switch(exp[i])
{
case'+':sum();
break;
case'-':diff();
break;
case'*':mul();
break;
case'/':div();
break;
case'^':power();
break;
default:
top++;
stack[top]=exp[i]-'0';
}
}
printf("the result is=%d\n",stack[top]);
}
int sum()
{
int op1,op2,res;
op1=stack[top];
top--;
op2=stack[top];
top--;
res=op1+op2;
top++;
stack[top]=res;
}
int diff()
{
int op1,op2,res;
op1=stack[top];
top--;
op2=stack[top];
top--;
res=op2-op1;
top++;
stack[top]=res;
}
int mul()
{
int op1,op2,res;
op1=stack[top];
top--;
op2=stack[top];
top--;
res=op1*op2;
top++;
stack[top]=res;
}
int div()
{
int op1,op2,res;
op1=stack[top];
top--;
op2=stack[top];
top--;
res=op2/op1;
top++;
stack[top]=res;
}
int power()
{
int op1,op2,res;
op1=stack[top];
top--;
op2=stack[top];
top--;
res=op2^op1;
top++;
stack[top]=res;
}




