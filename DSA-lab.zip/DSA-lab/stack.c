#include<stdio.h>
 void push();
 void pop();
 void display();
 int stack[100],top=-1,n=5;
 int x,choice,n,top;
 int main()
{
do
{
  printf("1.insert the stack \n");
  printf("2.delete the stack \n");
  printf("3.display the stack \n");
  printf("4. exit the stack \n");
  printf("enter your choice\n");
  scanf("%d",&choice);
  switch(choice)
		{
			case 1:	push();
				printf("insert the element\n");
				break;
			case 2:	pop();
			        printf("delete the elment\n");
				break;
			case 3:	display();
				printf("delete the element\n");
				break;
				}
}
	while(choice==1||choice==2||choice==3);
	return 0;
	}
    void push()
    {
    if(top==n-1)
    {						
	printf("stack is full");
	}
	else
	{
	top++;
	printf("enter the element");
	scanf("%d",&x);
	stack[top]=x;
	}
	}
	void pop()
	{
	if(top==-1)
	{
	printf("empty");
	}
	else
	{
	printf("element removed from stack is %d",stack[top]);
	top--;
	}	
      }
     void display ()
     {
     int i;
     if(top==-1)
     {
     top==-1;
    } 
     else
     {
     for(i=top;i>=0;i--)
     {
     printf("%d",stack[i]);
     }
     }
     }
     
