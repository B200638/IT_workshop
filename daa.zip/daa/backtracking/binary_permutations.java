import java.util.*;
import java.lang.*;
class bt
{
char wt[];
 bt(int n)
 {
   wt=new char[n];
   }
 int c=0;
 void fill(int n,int k)
 {
  if(k==n)
  {
   for(int i=0;i<n;i++)
   {
    System.out.print(wt[i]);
    }
   System.out.println("");
   c++;
  return;
  }
  for(char i='0';i<='1';i++)
  {
   wt[k]=i;
   fill(n,k+1);
  }
 }
}
class binary
{
 public static void main(String...args)
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the size");
  int n=sc.nextInt();
  bt b=new bt(n);
  b.fill(n,0);
  System.out.println("no.of premutations="+b.c);
  }
 }
   
