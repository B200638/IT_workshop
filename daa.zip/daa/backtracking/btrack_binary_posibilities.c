#include<stdio.h>//from 000-111 all posibilities
#include<string.h>
char a[10];
void fill(int k,int n)
{ 
 if(k==n)
 {
  printf("%s\n",a);
  }
 else 
 {
 for(int i='0';i<='1';i++)
 {
   a[k]=i;
   fill(k+1,n);
  }
 }
 }
 int main()
 {
  int n;
  printf("ente the size");
  scanf("%d",&n);
 fill(0,n);
  }
  
  
  
