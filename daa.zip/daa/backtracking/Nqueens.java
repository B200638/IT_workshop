import java.util.*;
import java.lang.Math;
class Nqueens
{
 int a[];
 int c=0;
 Nqueens(int n)
 {
  a=new int[n];
 }
  void fill(int n,int k)
  {
  if(k>n)
  {
  for(int i=0;i<n;i++)
  {
  System.out.print(" "+a[i]);
  }
  System.out.println("");
    c++;
  return;
  }
  for(int i=1;i<=n;i++)
  {
   if(isSafe(k,i))
   {
    a[k-1]=i;
    fill(n,k+1);
   }
  }
 }
 boolean isSafe(int k,int i)
 {
  for(int j=1;j<k;j++)
  {
   if(a[j-1]==i)
   return false;
   if(Math.abs(k-j)==Math.abs(i-a[j-1]))
   return false;
   }
   return true;
  }
 }
 class backtrack
 {
  public static void main(String...args)
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter the size");
   int n=sc.nextInt();
      Nqueens t=new Nqueens(n);
   t.fill(n,1);
   System.out.println("no.of ways: "+t.c);
   }
  }
