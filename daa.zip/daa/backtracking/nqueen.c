 #include<stdio.h>

#include<stdbool.h>

int a[20];

bool issafe(int k,int i)
{
    for(int j=0;j<k;j++)// for column
    {
        if(a[j]==i)
            return false;
            if(abs(k-j)==abs(i-a[j]))// to check it is diagonal 
            return false;
        
    }
    return true;
}

void queen(int n,int k)
{
    if(k==n)
    {
        for(int i=0;i<n;i++)
        {
            printf("%d ",a[i]);
}
        printf("\n");
        return;
    }

    for(int i=0;i<n;i++)
    {
        if(issafe(k,i))
        {
            a[k]=i;
            queen(n,k+1);
        }
    }
}
int main()
{
int n;
printf("enter the n");
scanf("%d",&n);
queen(n,0);
}

