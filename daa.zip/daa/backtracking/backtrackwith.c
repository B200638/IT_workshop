#include<stdio.h>
#include<stdbool.h>
#include<string.h>
int issafe(int k,int i,char a[])
{

for(int j=0;j<k;j++)
{
if (a[j]==i)
{
return 0;
}
}
return 1;
}
void back(int k,int n,char a[])
{
char i;
if(k==n)
{
printf("%s\n",a);
return;
}
for( i='a';i<='c';i++)
{
{
a[k]=i;
back(k+1,n,a);
}
}
}
int main()
{
char str[]="abc";
int n=strlen(str);
back(0,n,str);
 return 0;
 }

