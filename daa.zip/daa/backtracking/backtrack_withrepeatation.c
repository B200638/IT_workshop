 #include<stdio.h>//from 000-111 all posibilities
#include<string.h>
char a[10];
void fill(int k,int n,char x,char y)
{ 
 if(k==n)
 {
  printf("%s\n",a);
  }
 else 
 {
 for(int i='x';i<='y';i++)
 {
   a[k]=i;
   fill(k+1,n,x,y);
  }
 }
 }
 int main()
 {
  int n;
  char a,b;
  printf("ente the size");
  scanf("%d",&n);
  char x=getchar();
  char y=getchar();
 
 fill(0,n,x,y);
  }
  
  
  
