 #include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
int a[10];
bool issafe(int k,int i)
 {
  for(int j=0;j<k;j++)
  {
   if(a[j]==i)
   return false;
   if(abs(k-j)==abs(i-a[j]))
   return false;
  }
  return true; 
  }
void fill(int k,int n)
{ 
 if(k==n)
 {
 for(int i=0;i<n;i++)
 {
  printf("%d ",a[i]);
 
  }
    printf("\n");
  }

 for(int i=0;i<n;i++)
 {
  if(issafe(k,i))
  {
   a[k]=i;
   fill(k+1,n);
   }
  }
 }
 
 int main()
 {
  int n;
  printf("enter the array size");
  scanf("%d",&n);
  fill(0,n);
  }
  
  
  
