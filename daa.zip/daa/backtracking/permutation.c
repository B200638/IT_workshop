#include<stdio.h>
#include<stdbool.h>

bool issafe();
int a[20];
void per(int k,int n)
{
if(k==n)           // k is position
{
     for(int i=0;i<n;i++)
        {
            printf("%d ",a[i]);
}
        printf("\n");
        return;
    }
for(int i=0;i<2;i++)
{
a[k]=i;
per(k+1,n);
}
}
int main()
{
int n;
printf("enter the n");
scanf("%d",&n);
per(0,n);
}

