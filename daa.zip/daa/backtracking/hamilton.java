import java.util.*;
class hamilton
{
 int a[];
 int adj[][];
 int c=0;
 hamilton(int n)
 {
  a=new int[n];
  adj=new int[n][n];
 }
void fill(int n,int k)
{
 if(k==n)
 {
 for(int i=0;i<n;i++)
 {
  System.out.print(" "+a[i]);
  }
 System.out.println("");
 c++;
 }
 for(int i=0;i<n;i++)
 {
  if(isSafe(k,i,n))
  {
   a[k]=i;
   fill(n,k+1);
   }
  }
 }
boolean isSafe(int k,int i,int n)
{
 
 for(int j=0;j<k;j++)
 {
  if(a[j]==i)
  return false;
  if(adj[a[k-1]][i]==0)
  return false;
  if(k==n-1 && adj[i][a[0]]==0)
  return false;
  }
 return true;
}
}
class backtrack
{
 public static void main(String...args)
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the size");
  int n=sc.nextInt();
  hamilton h=new hamilton(n);
  System.out.println("enter the adjacent matrix");
  for(int i=0;i<n;i++)
  {
   for(int j=0;j<n;j++)
   {
    h.adj[i][j]=sc.nextInt();
    }
  }
  h.fill(n,0);
  System.out.println("total no.of possible cycles : "+h.c);
  }
 }
  
  
  
   
 
 
