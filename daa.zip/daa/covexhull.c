#include <stdio.h>

struct point {
    int x;
    int y;
};

int main() {
    int i, j, k, a, b, c, val, f = 0, n;
    printf("Enter the number of points: ");
    scanf("%d", &n);
    struct point p[n];
    printf("Enter the points (x and y coordinates):\n");
    for (i = 0; i < n; i++) {
        scanf("%d %d", &p[i].x, &p[i].y);
    }

    for (i = 0; i < n; i++) {
        for (j = i + 1; j < n; j++) {
            a = p[j].y - p[i].y;
            b = p[i].x - p[j].x;
            c = a * p[i].x + b * p[i].y;
            int nn = 0, np = 0;
            for (k = 0; k < n; k++) {
                if (k != i && k != j) {
                    val = a * p[k].x + b * p[k].y - c;
                    if (val > 0)
                        np++;
                    else if (val < 0)
                        nn++;
                }
            }
            if (np == 0 || nn == 0) {
                printf("%d %d and %d %d are convex hull\n", p[i].x, p[i].y, p[j].x, p[j].y);
            } else {
                printf("%d %d and %d %d are NOT convex hull\n", p[i].x, p[i].y, p[j].x, p[j].y);
            }
        }
    }
    return 0;
}

