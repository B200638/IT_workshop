#include<stdio.h>
#include<stdbool.h>
struct point
{
    int x;
    int y;
};

void main()
{
    int n;
    printf("Enter the no. of points: ");
    scanf("%d",&n);

    struct point p[n];

    for(int i=0;i<n;i++)
    {
        printf("point %d  X and Y : ",i);
        scanf("%d%d",&p[i].x,&p[i].y);
    }

    int a,b,c;int count=0; bool isBorder[n];

    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            int a=p[j].y-p[i].y;
            int b=p[i].x-p[j].x;
            int c=p[i].x*p[j].y-p[i].y*p[j].x;

           
            int np=0;int nn=0;int val;
            for(int k=0;k<n;k++)
            {
                val = a * p[k].x + b * p[k].y - c;
                if(val > 0)
                {
                    np++;
                }
                else if(val < 0)
                {
                    nn++;
                }
            }
             if(val==0)
             {
                isBorder[i]=true;
                isBorder[j]=true;
             }
        }
    }

    for(int i=0;i<n;i++)
    {
        if(isBorder[i]) 
        {
            printf("(%d,%d)\t",p[i].x,p[i].y);
            count++;
        }
    }
    printf("Count: %d",count);

}





// if(p[k].x==p[i].x || p[k].y)
//                 int val=a*p[k].x+b*p[k].y-c;
//                 if(val==0)
//                 {
//                     if(k!=i && k!=j) count++;
//                     count++;
//                     printf("(%d,%d)\t",p[k].x,p[k].y);
                    
//                 }
//                 count=count-2;
            