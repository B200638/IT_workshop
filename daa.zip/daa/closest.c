#include <stdio.h>
#include <math.h>

struct Point
{
    int x;
    int y;
};

int main()
 {
    int x1, y1, x2, y2, n, dist;
    printf("Enter the number of points: ");
    struct Point p[10];
    scanf("%d", &n);
    int i,j;
    printf("Enter coordinates for %d points:\n", n);
    for (int i = 0; i < n; i++) 
    {
        scanf("%d %d", &p[i].x, &p[i].y);
    }

    int min = 99999; 
    for (i = 0; i < n; i++) 
    {
        for (j = i + 1; j < n; j++)
         {
            dist = sqrt(pow(p[i].x - p[j].x, 2) + pow(p[i].y - p[j].y, 2));
            if (dist < min) 
            {
                x1 = p[i].x;
                y1 = p[i].y;
                x2 = p[j].x;
                y2 = p[j].y;
                min = dist; 
            }
        }
    }

 printf("The closest points are (%d, %d) and (%d, %d) with distance %d.\n", x1, y1, x2, y2, min);

}

