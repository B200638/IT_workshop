//finding sorted list by using quicksort
#include<stdio.h>
void quick(int a[],int low,int high);
int main()
{
int n,i;
printf("enter the array size");
scanf("%d",&n);
int a[n];
printf("enter the elements\n");
for(i=0;i<n;i++)
{
 scanf("%d",&a[i]);
 }
quick(a,0,n-1);//calling function
printf("after sorting list ; ");
for(i=0;i<n;i++)
{
 printf("%d ",a[i]);
 }
}
void quick(int a[],int low,int high) //function defination
{
int i,j,t,pivot;
if(low<high)
{
 i=low;
 j=high;
 pivot=low;
 while(i<j)
 {
  while(a[i]<=a[pivot])
  i++;
  while(a[j]>a[pivot])
  j--;
  if(i<j)
  {
   t=a[i];
   a[i]=a[j];
   a[j]=t;
   }
  }
 t=a[j];
 a[j]=a[pivot];
 a[pivot]=t;
 quick(a,low,j-1); //for recursion
 quick(a,j+1,high); //for recursion
 }
}
