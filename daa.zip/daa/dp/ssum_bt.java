import java.util.*;
class ssum_bt
{
 int a[];
 int wt[];
 int s;
 ssum_bt(int n)
 {
  a=new int[n];
  wt=new int[n];
  }
 void fill(int n,int k)
 {
  if(k==n)
  {
   print(n);
   return;
  }
 for(int i=0;i<=1;i++)
 {
  a[k]=i;
  fill(n,k);
  }
 }
 void print(int n)
 {
  int wb=0;
  for(int i=0;i<n;i++)
  {
   if(a[i]==1)
   {
   wb=wb+wt[i];
   }
  }
 if(wb==s)
 System.out.println("yes");
 else
 System.out.println("no");
 }
}
class backtrack
{
 public static void main(String...args)
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the size");
  int n=sc.nextInt();
   ssum_bt t=new ssum_bt(n);
  System.out.println("enter the bag weights");
  for(int i=0;i<n;i++)
  {
   t.wt[i]=sc.nextInt();
   }
  System.out.println("enter the subset sum value");
  t.s=sc.nextInt();
 
  t.fill(n,0);
  }
 }
