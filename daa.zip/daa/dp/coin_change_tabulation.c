#include<stdio.h>//no.of ways for getting given amount by given type of coins 
 
int cc(int n,int w,int wt[])
{
 int i,j,a[n+1][w+1];
 for(i=0;i<=n;i++)
 {
  for(j=0;j<=w;j++)
  {
    if(i==0 && j!=0)
    a[i][j]=0;
    else if(j==0)
    a[i][j]=1;
    else if(wt[i-1]<=j)
    a[i][j]=a[i][j-wt[i-1]]+a[i-1][j];
    else
    a[i][j]=a[i-1][j];
 }
 }
 return a[n][w];
}
int main()
{
 int n,i,w;
 printf("how many types of coins: ");
 scanf("%d",&n);
 int wt[n];
 printf("enter the type of coins:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
 }
 printf("enter the rupees:");
 scanf("%d",&w);
 printf("no.of ways: %d",cc(n,w,wt));
 }
 
 
 
