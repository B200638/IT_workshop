#include<stdio.h>
void fib(int a[],int n)
{
 int i;
 for(i=0;i<=n;i++)
 {
 if(i==0)
  {
  a[i]=0;
  }
 else if(i==1)
  {
  a[i]=1;
  }
 else
 {
 a[i]=a[i-1]+a[i-2];
 }
 }
printf("fibonacci numbers for %d are: ",n);
 for(i=0;i<=n;i++)
 {
 printf("%d ",a[i]);
 }
}
int main()
{
 int n,i;
 printf("enter any number");
 scanf("%d",&n);
 int a[n];
 fib(a,n);
 }
 
