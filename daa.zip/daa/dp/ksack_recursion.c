#include<stdio.h>//knapsack in recursion mode/without memorization
int knapsack(int n,int w,int wt[],int val[])// 5 17 wt 5 3 2 9 6 // val=7 10 15 18 24 //ans 57
{
 if(n==0||w==0)
 {
  return 0;
 }
 if(wt[n-1]<=w)
 { 
  int a=val[n-1]+knapsack(n-1,w-wt[n-1],wt,val);
  int b=(knapsack(n-1,w,wt,val));
   return (a>b?a:b);
  }
 else
 {
  return knapsack(n-1,w,wt,val);
  }
 }
void main()
{
 int n,w,i;
 printf("enter the no.of weight: ");
 scanf("%d",&n);
 printf("enter weight of the bag: ");
 scanf("%d",&w);
 int wt[n],val[n];
 for(i=0;i<n;i++)
 {
  printf("enter the weight and no.of variables\n");
  scanf("%d",&wt[i]);
  scanf("%d",&val[i]);
  }
 int c=knapsack(n,w,wt,val);
 printf("max value of knapsack:%d",c);
}
