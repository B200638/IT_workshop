#include<stdio.h>//it is the tabulation formate
void fib(int a[],int n)
{
 int i;
 for(i=0;i<=n;i++)
 {
 if(i==0)
  a[i]=0;
 else if(i==1)
  a[i]=1;
  else if(i==2)
  a[i]=2;
  else if(i==3)
  a[i]=3;
 else
 a[i]=a[i-1]+a[i-2];
 }
printf("no.of ways to reach the destination:%d",a[n]);
}
int main()
{
 int n,i;
 printf("enter number of steps: ");
 scanf("%d",&n);
 int a[n];
 fib(a,n);
 }
 
/*#include<stdio.h>
int ways(int a[],int n)
{
  if(a[n]!=-1)
  {
  return a[n]; 
  } 
    if(n==0)
    {
     return a[n]=0;
     }
    else if(n==1)
    {
    return a[n]=1;
    }
    else if(n==2)
    {
    return a[n]=2;
    }
    else if(n==3)
    {
    return a[n]=3;
    }
    else
    {
    return a[n]=ways(a,n-1)+ways(a,n-2);
    }
}  
int main()
{
    printf("enter the no.of steps;");
    int i,n;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<=n;i++)
    {
        a[i]=-1;
     }
    for(i=0;i<=n;i++)
    {
     a[i]=ways(a,i);
    }
    printf("no.of ways to reach the peak step are: %d",a[n]);
} */ 
