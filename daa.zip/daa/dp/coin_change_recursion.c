#include<stdio.h>//no.of ways for getting given amount by given type of coins 
#include<stdbool.h>
int cc(int n,int w,int wt[]) // here it n=3 wt=1 2 3 w=10 it means 3+3+3+1 =10 means which values gives minimum values
{
  
 if(n==0 && w!=0)
 return false;
 else if(w==0)
 return true;
 if(wt[n-1]<=w)
  return cc(n,w-wt[n-1],wt)+cc(n-1,w,wt);
 else
  return cc(n-1,w,wt);
 }

int main()
{
 int n,i,w;
 printf("how many types of coins: ");
 scanf("%d",&n);
 int wt[n];
 printf("enter the type of coins:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
 }
 printf("enter the rupees:");
 scanf("%d",&w);
 printf("no.of ways for required rupees by given coins:%d",cc(n,w,wt));
 }
 
 
 
