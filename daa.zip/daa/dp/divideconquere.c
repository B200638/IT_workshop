#include <stdio.h>
#include <math.h>
#include <limits.h>
#include <float.h>
#include <stdlib.h>

struct point {
    int x, y;
};

float min;
int indexi = 0, indexj = 0, i, j, n;

float bruteforce(struct point *p, int st, int end) {
    min = FLT_MAX;
    for (i = st; i < end - 1; i++) {
        for (j = i + 1; j < end; j++) {
            float d = sqrt(pow((p[i].x - p[j].x), 2) + pow((p[i].y - p[j].y), 2));
            printf("Checking points (%d, %d) and (%d, %d) -> Distance: %.6f\n", p[i].x, p[i].y, p[j].x, p[j].y, d);
            if (d < min) {
                min = d;
                indexi = i;
                indexj = j;
            }
        }
    }
    return min;
}

float closestp(struct point *p, int st, int end) {
    struct point s[20];
    int k = 0;
    float ld, rd, d, bd;
    if (end > st + 1)  
    {
        int mid = (st + end) / 2;
        ld = closestp(p, st, mid);
        rd = closestp(p, mid + 1, end);
        d = ld < rd ? ld : rd;
        for (i = st; i <= end; i++) {
            if (abs(p[i].x - p[mid].x) < d) {
                s[k++] = p[i];
            }
        }
        bd = bruteforce(s, 0, k);
        return bd < d ? bd : d;
    } else {
        return bruteforce(p, st, end);
    }
}

int main() {
    printf("Enter number of points: ");
    scanf("%d", &n);
    struct point p[n];
    printf("Enter the points:\n");
    for (i = 0; i < n; i++) {
        scanf("%d%d", &p[i].x, &p[i].y);
    }
    min = closestp(p, 0, n - 1);
    printf("Minimum shortest distance = %.6f\n", min);
    printf("Point 1: x1 = %d, y1 = %d\n", p[indexi].x, p[indexi].y);
    printf("Point 2: x2 = %d, y2 = %d\n", p[indexj].x, p[indexj].y);
    return 0;
}

