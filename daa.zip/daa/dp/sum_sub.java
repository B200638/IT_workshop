import java.util.*;
class backtrack
{
 backtrack(int n,int k)
 {
  int a[]=new int[n];
  if(k==n)
  {
   print(a,n);
   return;
  }
  for(int i=0;i<2;i++)
  {
   a[k]=i;
   backtrack(n,k+1);
   }
  }
 int print(int a[],int n)
 {
 int 
   
