#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
int dp[100][100];
int MCM(int i,int j,int a[])
{
int k,val;
if(dp[i][j]!=-1)
{
return dp[i][j];
}
if(i==j)
{
return dp[i][j]=0;
}
int min=INT_MAX;
for(k=i;k<j;k++)
{
val=MCM(i,k,a)+MCM(k+1,j,a)+a[i-1]*a[k]*a[j];
//}
if(val<min)
{
min=val;
}
}
return dp[i][j]=min;
}
int main()
{
int n;
printf("enter the value");
scanf("%d",&n);
int a[n];
printf("enter the array sizes");
for(int s=0;s<n;s++)
{
scanf("%d",&a[s]);
}
for(int p=0;p<=n;p++)
{
for(int q=0;q<=n;q++)
{
dp[p][q]=-1;
}}
printf("%d",MCM(1,n-1,a));
}
