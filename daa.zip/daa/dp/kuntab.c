#include<stdio.h>
#include<math.h>
int knapsack(int n,int w,int wt[],int val[])
{
int a[n+1][w+1];
int i,j;
for(i=0;i<n;i++)
{
for(j=0;j<w;j++)
{
if(i==0|| j==0)
{
a[i][j]=0;
}
else if(wt[i-1]<=j)
{
a[i][j]=fmax(val[i-1]+a[i][j-wt[i-1]],a[i-1][j]);
}
else
 a[i][j]=a[i-1][j];
}
}
return a[n][w];
}
int main()

{
int n,i,j,val,wt;
printf("enter the value of n:");
scanf("%d",&n);
int wt[n],val[n];
for(i=0;i<n;i++)
{
printf("enter the values and weight:");
scanf("%d",&wt[i]);
scanf("%d",&val[i]);
}
printf("max value of knapsack:%d",knapsack(n,w,wt,val));
return 0;
}
