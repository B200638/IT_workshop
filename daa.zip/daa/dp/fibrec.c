#include <stdio.h>

// Recursive function to compute the nth Fibonacci number
int fib(int n) {
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return fib(n - 1) + fib(n - 2);
    }
}

int main() {
    int n;
    printf("Enter any number: ");
    scanf("%d", &n);
    
    printf("Fibonacci numbers for %d are: ", n);
    for (int i = 0; i < n; i++) {
        printf("%d ", fib(i));
    }
    printf("\n");
    
    return 0;
}

