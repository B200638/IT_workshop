#include<stdio.h>
int ksack(int n,int w,int wt[],int val[])
{
 int a[n+1][w+1],i,j;
  
 for(i=0;i<=n;i++)
 {
  for(j=0;j<=w;j++)
  {
   if(i==0||j==0)
    a[i][j]=0;
   else if(wt[i-1]<=j)
   {
    int x=val[i-1]+a[i-1][j-wt[i-1]];
    int y=a[i-1][j];
    a[i][j]=(x>y?x:y);
   }
  else
  a[i][j]=a[i-1][j];
 }
 }
 return a[n][w];
}
int main()
{
 int n,w,i;
 printf("enter the no.of weight: ");
 scanf("%d",&n);
 printf("enter weight of the bag: ");
 scanf("%d",&w);
 int wt[n],val[n];
 for(i=0;i<n;i++)
 {
  printf("enter the weight and no.of variables\n");
  scanf("%d",&wt[i]);
  scanf("%d",&val[i]);
  }
 printf("max value of knapsack:%d",ksack(n,w,wt,val));
}
