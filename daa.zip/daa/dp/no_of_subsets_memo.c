 #include<stdio.h>
int ssum(int n,int w,int wt[])
{
 int a[n+1][w+1];
for(int i=0;i<=n;i++)
 {
  for(int j=0;j<=w;j++)
  {
    a[i][j]=-1;
  }
 }
 if(a[n][w]!=-1)
 return a[n][w];
else if(n==0&&w!=0)
return a[n][w]=0;
 else if(w==0)
return a[n][w]=1;
else if(wt[n-1]<=w)
return a[n][w]= ssum(n-1,w-wt[n-1],wt)+ssum(n-1,w,wt);
else
return a[n][w]=ssum(n-1,w,wt);
}
int main()
{
 int n,s,i;
 printf("enter the no.of elements: ");
 scanf("%d",&n);
 printf("enter the subset sum value: ");
 scanf("%d",&s);
  int wt[n];
 printf("enter the elements:\n");
 for(i=0;i<n;i++)
 {
   scanf("%d",&wt[i]);
 }
printf("no.of ways:%d",ssum(n,s,wt));
}
