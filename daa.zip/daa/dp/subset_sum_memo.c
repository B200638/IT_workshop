#include<stdio.h>
int ssum(int n,int w,int wt[],int a[n][w])
{
 if(a[n][w]!=-1)
 return a[n][w];
if(n==0&&w!=0)
return a[n][w]=0;
else if(w==0)
return a[n][w]=1;
else if(wt[n-1]<=w)
return a[n][w]=ssum(n-1,w-wt[n-1],wt,a)||ssum(n-1,w,wt,a);
else
return a[n][w]=ssum(n-1,w,wt,a);
}
int main()
{
 int n,s,i,j;
 printf("enter the no.of elements: ");
 scanf("%d",&n);
 printf("enter the subset sum value: ");
 scanf("%d",&s);
 int a[n+1][s+1],wt[n];
 printf("enter the elements:\n");
 for(i=0;i<n;i++)
 {
   scanf("%d",&wt[i]);
 }
 for(i=0;i<=n;i++)
 {
  for(j=0;j<=s;j++)
  {
    a[i][j]=-1;
  }
 }
 int b=ssum(n,s,wt,a);
 if(b!=0)
 printf("yes,value can find");
else
printf("no,value can't find");
}
