#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
int mcm(int n,int a[])
{int dp[n][n];


int l,i,j,k,val;
for(l=0;l<n;l++)
{
for(i=1;i<n-l;i++)
{
j=i+l;
if(i==j)
{
dp[i][j]=0;
continue;
}
int min=INT_MAX;
for(k=i;k<j;k++)
{
val=dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
dp[i][j]=min;}}
}}
return dp[1][n-1];
}
int main()
{
int n;
printf("enter the value");
scanf("%d",&n);
int a[n];
printf("enter the array sizes");
for(int s=0;s<n;s++)
{
scanf("%d",&a[s]);
}
printf("%d",mcm(n,a));
}
