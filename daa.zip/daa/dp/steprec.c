#include<stdio.h>

int ways(int n) {
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else if (n == 2) {
        return 2;
    } else if (n == 3) {
        return 3;
    } else {
        return ways(n-1) + ways(n-2);
    }
}

int main() {
    printf("Enter the number of steps: ");
    int n;
    scanf("%d", &n);
    printf("Number of ways to reach the peak step are: %d", ways(n));
    return 0;
}

