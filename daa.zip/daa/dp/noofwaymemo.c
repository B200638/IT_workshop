#include<stdio.h>
int ways(int a[],int n)
{
  if(a[n]!=-1)
  {
  return a[n]; 
  } 
    if(n==0)
    {
     return a[n]=0;
     }
    else if(n==1)
    {
    return a[n]=1;
    }
    else if(n==2)
    {
    return a[n]=2;
    }
    else if(n==3)
    {
    return a[n]=3;
    }
    else
    {
    return a[n]=ways(a,n-1)+ways(a,n-2);
    }
    }
    int main()
{
    printf("enter the no.of steps;");
    int i,n;
    scanf("%d",&n);
    int a[n+1];
    for(i=1;i<=n;i++)
    {
        a[i]=-1;
     }
     
    printf("no.of ways to reach the peak step are: %d",ways(a,n));
}
