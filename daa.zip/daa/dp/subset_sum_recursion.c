#include<stdio.h>
#include<stdbool.h>
bool ssum(int n,int w,int wt[])
{
 if(n==0&&w!=0)
 return false;
 if(w==0)
 return true;
 if(wt[n-1]<=w)
 return ssum(n-1,w-wt[n-1],wt)|| ssum(n-1,w,wt);
 else
 return ssum(n-1,w,wt);
 }
 
 int main()
 {
  int n,s,i;
  printf("enter the no.of weights: ");
  scanf("%d",&n);
  printf("enter the subset sum value: ");
  scanf("%d",&s);
  printf("enter the weights:\n");
  int wt[n];
  for(i=0;i<n;i++)
  {
   scanf("%d",&wt[i]);
  }
  bool sum=ssum(n,s,wt);
  if(sum==true)
  printf("yes, can find value");
  else
  printf("no,can't find value");
 }
 
