#include<stdio.h>
int fib(int a[],int n)
{
 if(a[n]!=-1)
 {
 return a[n];
 }
 if(n==0)
 {
 return a[n]=0;
 }
 else if(n==1)
 {
 return a[n]=1;
 }
 else
 {
 return a[n]=fib(a,n-1)+fib(a,n-2);
 }
}
int main()
{
 int n,i;
 printf("enter any number");
 scanf("%d",&n);
 int a[n];
 for(i=0;i<n;i++)
 {
  a[i]=-1;
  a[i]=fib(a,i);
  }
 printf("fibonacci numbers for %d are: ",n);
 for(i=0;i<n;i++)
 {
  printf("%d ",a[i]);
  }
 }
