  #include<stdio.h>// minimum no.of coins required for getting given amount 
#include<limits.h>
int cc(int n,int w,int wt[])
{
 int a[n+1][w+1],x,y;
 for(int i=0;i<=n;i++)
 {
 for(int j=0;j<=w;j++)
 {
  if(i==0 && j!=0)
   a[i][j]=INT_MAX-1000;
 else if(j==0)
   a[i][j]=0;
 else if(wt[i-1]<=j)
 { 
   x=1+a[i][j-wt[i-1]];
   y=a[i-1][j];
   a[i][j]=(x<y?x:y);
 }
 else
   a[i][j]=a[i-1][j];
 }
}
return a[n][w];
}
int main()
{
 int n,i,w;
 printf("how many types of coins: ");
 scanf("%d",&n);
 int wt[n];
 printf("enter the type of coins:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
 }
 printf("enter the rupees:");
 scanf("%d",&w);
 printf("minimum no.of coins:%d",cc(n,w,wt));
 }
 
 
 
