import java.util.*;
import java.lang.Math;
class ksack
{
int a[][],val[],wt[];
ksack(int n,int w)
{
 int i,j;
 wt=new int[n];
 val=new int[n];
 a=new int[n+1][w+1];
 Scanner sc=new Scanner(System.in);
 for(i=0;i<n;i++)
 {
  System.out.println("enter the weight and no.of variables\n");
   wt[i]=sc.nextInt();
   val[i]=sc.nextInt();
  }
  for(i=0;i<=n;i++)
 {
  for(j=0;j<=w;j++)
  {
   a[i][j]=-1;
   }
  }
 }
int ks(int n,int w)
{
 if(a[n][w]!=-1)
  return a[n][w];
 if(n==0||w==0)
 return a[n][w]=0;
 else if(wt[n-1]<=w)
 return Math.max(val[n-1]+ks(n-1,w-wt[n-1]),ks(n-1,w));
 else
 return a[n][w]=ks(n-1,w);
 }
}
class test
{
public static void main(String...args)
{
 Scanner sc=new Scanner(System.in);
 System.out.println("enter the no.of weight: ");
  int n=sc.nextInt();
 System.out.println("enter weight of the bag: ");
  int w=sc.nextInt();
 ksack k=new ksack(n,w);
  int max=k.ks(n,w);
 System.out.println("max value of knapsack:"+max);
}
}
