#include<stdio.h>//no.of ways for subset sum in recursion mode/without memorization
int ssum(int n,int w,int wt[])
{
 if(n==0&&w!=0)
  return 0;
  if(w==0)
  return 1;
 else if(wt[n-1]<=w)
 {
   return ssum(n-1,w-wt[n-1],wt)+ssum(n-1,w,wt);
  }
 else
  return ssum(n-1,w,wt);
 }
void main()
{
 int n,s,i;
 printf("enter the no.of elements: ");
 scanf("%d",&n);
 printf("enter subset sum value: ");
 scanf("%d",&s);
 int wt[n];
 printf("enter the elements:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
  }
 int c=ssum(n,s,wt);
 printf("no.of ways:%d",c);
}
