#include<stdio.h>
#include<stdlib.h>
#include<limits.h> //4 //2,3,4,2===36
int MCM(int i,int j,int a[])
{
int k,val;
if(i==j)
{
return 0;
}
int min=INT_MAX;
for(int k=i;k<j;k++)
{
val=MCM(i,k,a)+MCM(k+1,j,a)+a[i-1]*a[k]*a[j];

if(val<min)
{
min=val;
}}
return min;
}
int main()
{
int n;
printf("enter the value");
scanf("%d",&n);
int a[n];
printf("enter the sizes");
for(int i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("%d",MCM(1,n-1,a));
}
