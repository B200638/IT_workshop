#include<stdio.h>
int knapsack(int n,int w,int wt[],int val[])
{
 int a[n+1][w+1],i,j;
 for(i=0;i<=n;i++)
 {
  for(j=0;j<=w;j++)
  {
   a[i][j]=-1;
   }
  }
 if(a[n][w]!=-1)
  return a[n][w];
 if(n==0||w==0)
 return a[n][w]=0;
 if(wt[n-1]<=w)
 {
  int x=val[n-1]+knapsack(n-1,w-wt[n-1],wt,val);
  int y=knapsack(n-1,w,wt,val);
   return a[n][w]=(x>y?x:y);
  }
 else
 return a[n][w]=knapsack(n-1,w,wt,val);
}
int main()
{
 int n,w,i;
 printf("enter the no.of weight: ");
 scanf("%d",&n);
 
 printf("enter weight of the bag: ");
 scanf("%d",&w);
 
 int wt[n],val[n];
 for(i=0;i<n;i++)
 {
  printf("enter the weight and no.of variables\n");
  scanf("%d",&wt[i]);
  scanf("%d",&val[i]);
  }
   int b=knapsack(n,w,wt,val);
 printf("max value of knapsack:%d",b );
}
