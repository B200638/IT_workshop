#include<stdio.h>
#include<stdbool.h>
int ssum(int n,int w,int wt[])
{
 if(n==0&&w!=0)
 return false;
 if(w==0)
 return true;
 if(wt[n-1]<=w)
 return ssum(n-1,w-wt[n-1],wt)||ssum(n-1,w,wt);
 else
 return ssum(n-1,w,wt);
 }
 
 int main()
 {
  int n,sum=0,i;
  printf("enter the no.of weights: ");
  scanf("%d",&n);
  printf("enter the weights:\n");
  int wt[n];
  for(i=0;i<n;i++)
  {
   scanf("%d",&wt[i]);
   sum=sum+wt[i];
  }
  int w=sum/2;
  int b=ssum(n,w,wt);
  if(sum%2!=0 ||b==0)
  printf("no,can't find equal sum partion");
  else 
   printf("yes,we can find equal sum partition ");
  }
 
 
