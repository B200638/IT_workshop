#include<stdio.h>
#include<math.h>
#include<limits.h>
struct point
{
    int x;
    int y;
};

void main()
{
    int n,x1,y1;
    printf("enter number of points:");
    scanf("%d",&n);
    struct point p[n];
    for(int i=0;i<n;i++)
    {
        printf("Enter %d points (x,y):",i+1);
        scanf("%d%d",&p[i].x,&p[i].y);
    }

    double avg_min=INT_MAX;
    for(int i=0;i<n;i++)
    {
        double sum=0;
        for(int j=0;j<n;j++)
        {
            sum+=sqrt( pow((p[j].x-p[i].x),2) + pow((p[j].y-p[i].y),2));
        }

        double avg_sum=sum/(n-1);

        if(avg_sum<avg_min)
        {
            avg_min=avg_sum;
            x1=p[i].x;
            y1=p[i].y;
        }
    }
    printf("AVG Distance: %lf ",avg_min);
    printf("\nPoint (%d,%d)",x1,y1);
    // printf("%d",avg_min);
 }
