#include<stdio.h>
int main()
 {
  int n,i,j,t=0;
  printf("enter the array size: ");
  scanf("%d",&n);
  int a[n];
 printf("enter the elements\n");
  for(i=0;i<n;i++)
  {
   scanf("%d",&a[i]);
  }
  for(i=0;i<n;i++)
  {
   for(j=i+1;j<n;j++)
   {
    if(a[i]>a[j])
    {
     t=a[i];
     a[i]=a[j];
     a[j]=t;
    }
   }
  }
 printf("enter the searching element: ");
 int e;
 scanf("%d",&e);
 int mid=0,low=0,high=n-1,f=0;
 while(low<=high)
 {
  mid=(low+high)/2;
  if(a[mid]==e)
  {f=1;
  break;
  }
  if(e>a[mid])
  low=mid+1;
  else
  high=mid-1;
  }
 if(f==1)
 printf("element %d is found at index%d ",e, mid);
 else
 printf("element is not found");
 }
