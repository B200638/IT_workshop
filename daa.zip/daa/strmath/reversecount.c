#include<stdio.h>
#include<string.h>
int main()
{
 char a[50],b[50],r[50];
 printf("enter the main string and sub string\n");
 gets(a);
 gets(b);
 int i,f,j,t=0,c=0;
 int l=strlen(b);
for(i=l-1;i>=0;i--)
{
 r[t++]=b[i];
}
 for(i=0;i<=(strlen(a)-strlen(r));i++)
 {   
  if(r[0]==a[i])
  { 
   f=0;
  for(j=0;j<strlen(r);j++)
  { 
  if(r[j]!=a[j+i])
  {
   f=1;
   break;
   }
  }
 if(f==0)
 {
 c++;
 }
}
}
printf("matching count=%d",c);
}
