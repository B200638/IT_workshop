#include<stdio.h>
#include<string.h>
void main()
{
 char m[50],s[50];
 printf("enter the main string and sub string\n");
 gets(m);
 gets(s);
 int i,f,j,c=0;
 for(i=0;i<=(strlen(m)-strlen(s));i++)
 {   
  if(s[0]==m[i])
  { 
   f=0;
  for(j=0;j<strlen(s);j++)
  { 
  if(s[j]!=m[j+i])
  {
   f=1;
   break;
   }
  }
 if(f==0)
 c++;
}
}
 printf("match count %d",c);
}
